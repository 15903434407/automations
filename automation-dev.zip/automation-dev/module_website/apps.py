from django.apps import AppConfig


class ModuleWebsiteConfig(AppConfig):
    name = 'module_website'
